import json
import boto3

def lambda_handler(event, context):
    success = False
    rating_id = event['pet_id'] + event['username']
    dynamodb = boto3.resource('dynamodb', region_name="ap-southeast-2")
    
    table = dynamodb.Table('rating')
    response = table.get_item(Key={'id': rating_id})

    if 'Item' in response:
        table.update_item(
            Key={'id':rating_id},
            UpdateExpression="set rating=:r",
            ExpressionAttributeValues={
                ':r': event['rating']
            }
        )
        success = True
    else:
        table.put_item(
            Item = {
                'id': rating_id,
                'pet_id': event['pet_id'],
                'rating': event['rating'],
                'username': event['username']
            }
        )
        success = True
    
    return {
        'statusCode': 200,
        'success': success
    }
