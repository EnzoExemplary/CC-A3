import json
import boto3
import uuid

def lambda_handler(event, context):
    dynamodb = boto3.resource('dynamodb', region_name="ap-southeast-2")
    
    id = str(uuid.uuid4())
    
    table = dynamodb.Table('comment')
    table.put_item(
        Item={
            "id": id,
            "pet_id": event['pet_id'],
            "text": event['text'],
            "username": event['username']
        }
    )
    
    return {
        'statusCode': 200
    }
