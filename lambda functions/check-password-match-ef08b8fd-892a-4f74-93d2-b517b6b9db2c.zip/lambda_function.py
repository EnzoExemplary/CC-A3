import json
import boto3

def lambda_handler(event, context):
    match = False
    dynamodb = boto3.resource('dynamodb', region_name="ap-southeast-2")
    
    table = dynamodb.Table('user')
    response = table.get_item(Key={'username': event['username']})
    
    if 'Item' in response:
        user = response['Item']
        password = user['password']
        if(password == event['password']):
            match = True
    
    return {
        'statusCode': 200,
        'match': match
    }
