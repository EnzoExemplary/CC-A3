import json
import boto3
from boto3.dynamodb.conditions import Attr

def lambda_handler(event, context):
    comments = None

    dynamodb = boto3.resource('dynamodb', region_name="ap-southeast-2")
    
    table = dynamodb.Table('comment')
    response = table.scan(FilterExpression=Attr('pet_id').eq(event['pet_id']))
    
    if 'Items' in response:
        comments = response['Items']
    
    
    return {
        'statusCode': 200,
        'comments': comments
    }
