import json
import boto3
import random

def lambda_handler(event, context):
    rand_pet = None
    pets = None
    dynamodb = boto3.resource('dynamodb', region_name="ap-southeast-2")
    
    table = dynamodb.Table('pet')
    response = table.scan(ProjectionExpression = "id")
    
    if 'Items' in response:
        pets = response['Items']

    rand_pet_num = random.randint(0, len(pets) - 1)
    rand_pet_id = (pets[rand_pet_num])['id']

    response = table.get_item(Key={'id': rand_pet_id})
    
    if 'Item' in response:
        rand_pet = response['Item']

    return {
        'statusCode': 200,
        'pet': rand_pet
    }
