import json
import boto3

def lambda_handler(event, context):
    rating = 0
    dynamodb = boto3.resource('dynamodb', region_name="ap-southeast-2")
    
    table = dynamodb.Table('rating')
    response = table.get_item(Key={'id': event['id']})
    
    if 'Item' in response:
        rating_item = response['Item']
        rating = rating_item['rating']
        
    return {
        'statusCode': 200,
        'rating': rating
    }
