import json
import boto3
from boto3.dynamodb.conditions import Attr

def lambda_handler(event, context):
    success = False
    info = ''

    dynamodb = boto3.resource('dynamodb', region_name="ap-southeast-2")
    
    table = dynamodb.Table('user')
    response = table.get_item(Key={'username': event['username']})
    
    if not 'Item' in response:
        response = table.scan(FilterExpression=Attr('email').eq(event['email']))
        items = response['Items']
        if not items :
            response = table.put_item(
                Item={
                    'username': event['username'],
                    'email': event['email'],
                    'password': event['password'],
                    'icon_url': '',
                    'profile_bio': '',
                    'num_pets': 0
                })
            success = True
        else:
           info = 'Email already registered'
    else:
        info = 'Username already taken'
    
    return {
        'statusCode': 200,
        'success': success,
        'info': info
    }
