import json
import boto3

def lambda_handler(event, context):
    pet = None
    dynamodb = boto3.resource('dynamodb', region_name="ap-southeast-2")
    
    table = dynamodb.Table('pet')
    response = table.get_item(Key={'id': event['id']})
    
    if 'Item' in response:
        temp_pet = response['Item']
        pet = {
            "avg_rating": None, 
            "id": None, 
            "img_url": None, 
            "name": None, 
            "owner": None,
            "total_ratings": None
        }
        
        pet['avg_rating'] = temp_pet['avg_rating']
        pet['id'] = temp_pet['id']
        pet['img_url'] = temp_pet['img_url']
        pet['name'] = temp_pet['name']
        pet['owner'] = temp_pet['owner']
        pet['total_ratings'] = temp_pet['total_ratings']
        
    return {
        'statusCode': 200,
        'pet': pet
    }
