import json
import boto3
from boto3.dynamodb.conditions import Attr

def lambda_handler(event, context):
    pets = {}

    dynamodb = boto3.resource('dynamodb', region_name="ap-southeast-2")
    
    table = dynamodb.Table('pet')
    response = table.scan(
        FilterExpression=Attr('owner').eq(event['username']),
        ProjectionExpression = 'id, img_url, #n, #o',
        ExpressionAttributeNames = {'#n': 'name', '#o': 'owner'})
    
    if 'Items' in response:
        pets = response['Items']

    return {
        'statusCode': 200,
        'pets': pets
    }
