import json
import boto3

def lambda_handler(event, context):
    success = False
    dynamodb = boto3.resource('dynamodb', region_name="ap-southeast-2")
    
    table = dynamodb.Table('user')
    response = table.get_item(Key={'username': event['username']})

    if 'Item' in response:
        table.update_item(
            Key={'username':event['username']},
            UpdateExpression="set profile_bio=:b",
            ExpressionAttributeValues={
                ':b': event['new_bio']
            }
        )
        success = True

    
    return {
        'statusCode': 200,
        'success': success
    }
