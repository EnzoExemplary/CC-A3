import json
import boto3
import base64
from botocore.exceptions import ClientError

def lambda_handler(event, context):
    success = True
    bucket = 'elasticbeanstalk-ap-southeast-2-671015575440'
    filename = 'cc-a3/' + event['folder_name'] + '/' + event['username'] + str(event['num_pets'])
    filename += '.png'
    s3_client = boto3.client('s3')
    
    try:
        #Decode image from base64
        image = event['image']
        image = base64.b64decode(image)
    
        response = s3_client.put_object(
            ACL = 'public-read',
            Body = image, 
            Bucket = bucket, 
            Key = filename
        )
    except ClientError as e:
        success = False
   
    dynamodb = boto3.resource('dynamodb', region_name="ap-southeast-2")
   
    #Update num_pets for user
    num_pets = event['num_pets'] + 1
    table = dynamodb.Table('user')
    table.update_item(
        Key={'username': event['username']},
        UpdateExpression="set num_pets=:n",
        ExpressionAttributeValues={
            ':n': num_pets
        }
    )
    
    #Add pet to pet table
    table = dynamodb.Table('pet')
    pet_id = event['username'] + str(event['num_pets'])
    pet_img_url = 'https://' + bucket + '.s3-ap-southeast-2.amazonaws.com/' + filename
    table.put_item(
        Item={
            "avg_rating": 0,
            "id": pet_id,
            "img_url": pet_img_url,
            "name": event['pet_name'],
            "owner": event['username'],
            "total_ratings": 0
        }
    )
    
    return {
        'statusCode': 200,
        'success': success
    }
