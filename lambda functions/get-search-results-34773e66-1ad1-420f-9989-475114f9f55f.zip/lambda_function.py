import json
import boto3
from boto3.dynamodb.conditions import Attr

def lambda_handler(event, context):
    resulting_pets = []

    dynamodb = boto3.resource('dynamodb', region_name="ap-southeast-2")
    
    table = dynamodb.Table('pet')
    
    response = table.scan(
        ProjectionExpression = 'id, img_url, #n, #o',
        ExpressionAttributeNames = {'#n': 'name', '#o': 'owner'}
    )
    
    if event['search'] == '':
        if 'Items' in response:
            resulting_pets = response['Items']      
    else:
        if 'Items' in response:
            pets = response['Items']
            
            for pet in pets:
                if event['search'].upper() in pet['name'].upper():
                    resulting_pets.append(pet)
    
    return {
        'statusCode': 200,
        'pets': resulting_pets
    }
