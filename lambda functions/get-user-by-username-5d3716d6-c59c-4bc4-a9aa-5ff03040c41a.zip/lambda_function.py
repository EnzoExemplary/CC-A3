import json
import boto3

def lambda_handler(event, context):
    user = None
    dynamodb = boto3.resource('dynamodb', region_name="ap-southeast-2")
    
    table = dynamodb.Table('user')
    response = table.get_item(Key={'username': event['username']})
    
    if 'Item' in response:
        temp_user = response['Item']
        user = {"username":None,"icon_url":None,"profile_bio":None}
        user['username'] = temp_user['username']
        user['icon_url'] = temp_user['icon_url']
        user['profile_bio'] = temp_user['profile_bio']
        user['num_pets'] = temp_user['num_pets']
        
    return {
        'statusCode': 200,
        'user': user
    }
