import json
import boto3
from boto3.dynamodb.conditions import Attr

def lambda_handler(event, context):
    rated_pets = []

    dynamodb = boto3.resource('dynamodb', region_name="ap-southeast-2")
    
    table = dynamodb.Table('rating')
    response = table.scan(
        FilterExpression=Attr('username').eq(event['username']),
        ProjectionExpression = 'pet_id, rating')
    
    
    if 'Items' in response:
        ratings = response['Items']
        
        table = dynamodb.Table('pet')
        
        for i in range(len(ratings)):
            rating_item = ratings[i]
            pet_id = rating_item['pet_id']
            rating = rating_item['rating']
            
            response = table.get_item(
                Key={'id': pet_id},
                ProjectionExpression = 'img_url, #n, #o',
                ExpressionAttributeNames = {'#n': 'name', '#o': 'owner'})
            
            if 'Item' in response:
                pet = response['Item']
                rated_pet = {
                    'pet_id': None,
                    'img_url': None,
                    'name': None,
                    'owner': None,
                    'rating': None
                }
                
                rated_pet['pet_id'] = pet_id
                rated_pet['img_url'] = pet['img_url']
                rated_pet['name'] = pet['name']
                rated_pet['owner'] = pet['owner']
                rated_pet['rating'] = rating

                rated_pets.append(rated_pet)

    return {
        'statusCode': 200,
        'rated_pets': rated_pets
    }
