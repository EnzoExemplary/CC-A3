import json
import boto3
from boto3.dynamodb.conditions import Attr

def lambda_handler(event, context):
    ratings = {}
    average_rating = 0

    dynamodb = boto3.resource('dynamodb', region_name="ap-southeast-2")
    
    table = dynamodb.Table('rating')
    response = table.scan(FilterExpression=Attr('pet_id').eq(event['pet_id']))
    
    if 'Items' in response:
        ratings = response['Items']
        
    for i in range(len(ratings)):
        average_rating += int(ratings[i]['rating'])
    
    average_rating = average_rating / len(ratings)
    average_rating = round(average_rating, 1)
    
    return {
        'statusCode': 200,
        'average_rating': average_rating
    }
